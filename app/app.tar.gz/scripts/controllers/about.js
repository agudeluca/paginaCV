'use strict';

/**
 * @ngdoc function
 * @name agustindelucaApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the agustindelucaApp
 */
angular.module('agustindelucaApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
